/**
 * js/about.js
 * ─────────────────────────────────────────────────────
 * Modul halaman Home — merender kartu "Tentang Program"
 * dari DATA.about (data.js).
 * ─────────────────────────────────────────────────────
 */

const About = (() => {

  /**
   * Buat HTML untuk satu kartu about.
   * @param {{ icon, title, text }} item
   * @returns {string} HTML string
   */
  function createCard(item) {
    return `
      <div class="about-card">
        <div class="about-card__icon">${item.icon}</div>
        <h3 class="about-card__title">${item.title}</h3>
        <p class="about-card__text">${item.text}</p>
      </div>
    `;
  }

  /**
   * Render semua kartu ke dalam #aboutGrid.
   */
  function render() {
    const grid = document.getElementById('aboutGrid');
    if (!grid) return;

    grid.innerHTML = DATA.about.map(createCard).join('');
  }

  /**
   * Inisialisasi modul about.
   */
  function init() {
    render();
  }

  return { init };

})();
