/**
 * js/data.js
 * ─────────────────────────────────────────────────────
 * Pusat data konten website Lentera Literasi.
 * Ubah data di sini untuk memperbarui konten website.
 * ─────────────────────────────────────────────────────
 */

const DATA = {

  /* ─── Data kartu "Tentang Program" ─── */
  about: [
    {
      icon: '🎯',
      title: 'Tujuan',
      text: 'Meningkatkan minat dan budaya baca masyarakat Telukjambe Timur, khususnya anak-anak dan remaja, sebagai fondasi kecerdasan bangsa.'
    },
    {
      icon: '🌱',
      title: 'Manfaat',
      text: 'Memberikan akses buku gratis, menumbuhkan kreativitas, serta membuka wawasan masyarakat melalui kegiatan literasi yang menyenangkan.'
    },
    {
      icon: '🏡',
      title: 'Peran TBM',
      text: 'Taman Bacaan Masyarakat menjadi ruang belajar yang inklusif, ramah, dan mudah dijangkau oleh seluruh lapisan masyarakat.'
    }
  ],

  /* ─── Data TBM ─── */
  tbm: [
    {
      id: 1,
      icon: '📖',
      area: 'Wadas',
      nama: 'TBM Cahaya Wadas',
      deskripsi: 'Taman bacaan berbasis komunitas yang menyediakan koleksi buku anak, remaja, dan buku keterampilan untuk warga Desa Wadas dan sekitarnya.',
      alamat: 'Jl. Raya Wadas No. 12, Desa Wadas, Telukjambe Timur, Karawang',
      kontak: '+62 812-3456-7890',
      jadwal: 'Senin – Sabtu',
      buka: true
    },
    {
      id: 2,
      icon: '🌟',
      area: 'Sukaluyu',
      nama: 'TBM Bintang Sukaluyu',
      deskripsi: 'Ruang literasi aktif menyelenggarakan mendongeng, belajar bersama, dan pelatihan membaca bagi anak-anak usia dini.',
      alamat: 'Jl. Sukaluyu Raya No. 5, Desa Sukaluyu, Telukjambe Timur, Karawang',
      kontak: '+62 813-2345-6789',
      jadwal: 'Setiap Hari',
      buka: true
    },
    {
      id: 3,
      icon: '🏛️',
      area: 'Puseurjaya',
      nama: 'TBM Tunas Puseurjaya',
      deskripsi: 'Berlokasi di balai desa dengan koleksi lengkap meliputi buku pelajaran, novel, dan referensi pertanian untuk warga.',
      alamat: 'Balai Desa Puseurjaya, Jl. Puseurjaya No. 1, Telukjambe Timur',
      kontak: '+62 821-3456-7890',
      jadwal: 'Selasa – Minggu',
      buka: true
    },
    {
      id: 4,
      icon: '🌸',
      area: 'Margamulya',
      nama: 'TBM Mekar Margamulya',
      deskripsi: 'Berbasis masjid, terbuka untuk umum dengan program kelas literasi Al-Qur\'an dan buku-buku islami untuk seluruh keluarga.',
      alamat: 'Komplek Masjid Al-Hidayah, Desa Margamulya, Telukjambe Timur',
      kontak: '+62 822-4567-8901',
      jadwal: 'Setiap Hari',
      buka: true
    },
    {
      id: 5,
      icon: '🚀',
      area: 'Sirnabaya',
      nama: 'TBM Cerdas Sirnabaya',
      deskripsi: 'Dilengkapi pojok digital, koleksi buku sains & teknologi, serta program coding dasar untuk anak dan remaja.',
      alamat: 'Jl. Sirnabaya Indah Blok C No. 3, Desa Sirnabaya, Telukjambe Timur',
      kontak: '+62 831-5678-9012',
      jadwal: 'Senin, Rabu, Jumat',
      buka: false
    },
    {
      id: 6,
      icon: '🎨',
      area: 'Sukaluyu',
      nama: 'TBM Kreasi Sukaluyu',
      deskripsi: 'Memadukan buku dengan seni dan kerajinan. Tersedia koleksi majalah dan perlengkapan menggambar gratis.',
      alamat: 'RT 05/RW 02, Desa Sukaluyu, Telukjambe Timur, Karawang',
      kontak: '+62 856-6789-0123',
      jadwal: 'Kamis – Minggu',
      buka: true
    },
    {
      id: 7,
      icon: '🌿',
      area: 'Sukaharja',
      nama: 'TBM Hijau Sukaharja',
      deskripsi: 'Berbasis alam di tepi sungai dengan koleksi buku lingkungan hidup, pertanian, dan kesehatan. Suasana nyaman untuk membaca.',
      alamat: 'Jl. Sungai Citarum No. 7, Desa Sukaharja, Telukjambe Timur',
      kontak: '+62 877-7890-1234',
      jadwal: 'Senin – Sabtu',
      buka: true
    },
    {
      id: 8,
      icon: '👦',
      area: 'Margamulya',
      nama: 'TBM Anak Bangsa Margamulya',
      deskripsi: 'Khusus usia 4–15 tahun, program membaca interaktif, lomba cerpen, dan perpustakaan keliling setiap bulan.',
      alamat: 'Perumahan Griya Indah Blok A5, Desa Margamulya, Telukjambe Timur',
      kontak: '+62 888-8901-2345',
      jadwal: 'Setiap Hari',
      buka: true
    }
  ],

  /* ─── Data kontak ─── */
  kontak: [
    { icon: '📱', label: 'Nomor HP / WhatsApp', value: '+62 812-3456-7890',        link: 'https://wa.me/6281234567890' },
    { icon: '✉️', label: 'Email',                value: 'lenteraliterasi@gmail.com', link: 'mailto:lenteraliterasi@gmail.com' },
    { icon: '📍', label: 'Lokasi Program',       value: 'Telukjambe Timur, Karawang, Jawa Barat', link: null },
    { icon: '🕐', label: 'Jam Operasional',      value: 'Senin – Jumat, 08.00 – 16.00 WIB',       link: null }
  ]

};
