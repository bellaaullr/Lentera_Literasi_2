/**
 * js/kontak.js
 * ─────────────────────────────────────────────────────
 * Modul halaman Kontak.
 * - Render kartu info kontak dari DATA.kontak (data.js)
 * - Validasi & submit form dengan pesan sukses
 * ─────────────────────────────────────────────────────
 */

const Kontak = (() => {

  /**
   * Buat HTML satu kartu info kontak.
   * @param {{ icon, label, value, link }} item
   * @returns {string}
   */
  function createInfoCard(item) {
    const valueHTML = item.link
      ? `<a class="k-value k-value--link" href="${item.link}" target="_blank">${item.value}</a>`
      : `<span class="k-value">${item.value}</span>`;

    return `
      <div class="k-card">
        <span class="k-card__icon">${item.icon}</span>
        <div>
          <div class="k-card__label">${item.label}</div>
          ${valueHTML}
        </div>
      </div>
    `;
  }

  /**
   * Render semua kartu info kontak ke dalam #kontakInfo.
   */
  function renderInfo() {
    const wrap = document.getElementById('kontakInfo');
    if (!wrap) return;
    wrap.innerHTML = DATA.kontak.map(createInfoCard).join('');
  }

  /**
   * Validasi email sederhana menggunakan regex.
   * @param {string} email
   * @returns {boolean}
   */
  function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  /**
   * Tampilkan pesan sukses dan reset form setelah 4 detik.
   * @param {HTMLFormElement} form
   */
  function showSuccess(form) {
    const successEl = document.getElementById('formSuccess');
    form.style.display    = 'none';
    successEl.style.display = 'flex';

    setTimeout(() => {
      form.reset();
      form.style.display      = '';
      successEl.style.display = 'none';
    }, 4000);
  }

  /**
   * Handler submit form kontak.
   * @param {SubmitEvent} e
   */
  function handleSubmit(e) {
    e.preventDefault();

    const nama   = document.getElementById('fNama').value.trim();
    const email  = document.getElementById('fEmail').value.trim();
    const subjek = document.getElementById('fSubjek').value.trim();
    const pesan  = document.getElementById('fPesan').value.trim();

    // Cek semua field terisi
    if (!nama || !email || !subjek || !pesan) {
      alert('Harap lengkapi semua kolom sebelum mengirim.');
      return;
    }

    // Validasi format email
    if (!isValidEmail(email)) {
      alert('Format email tidak valid. Contoh: nama@email.com');
      return;
    }

    showSuccess(e.target);
  }

  /**
   * Inisialisasi modul kontak.
   */
  function init() {
    renderInfo();

    const form = document.getElementById('kontakForm');
    form?.addEventListener('submit', handleSubmit);
  }

  return { init };

})();
