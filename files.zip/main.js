/**
 * js/main.js
 * ─────────────────────────────────────────────────────
 * Entry point — jalankan semua modul setelah DOM siap.
 *
 * Urutan inisialisasi:
 *   1. Navigation  → routing halaman + navbar
 *   2. About       → render kartu tentang program
 *   3. TBM         → render kartu TBM + filter
 *   4. Kontak      → render info kontak + form
 * ─────────────────────────────────────────────────────
 */

document.addEventListener('DOMContentLoaded', () => {

  Navigation.init();  // navigasi SPA + hamburger + scroll
  About.init();       // kartu tentang program
  TBM.init();         // daftar TBM + filter chip
  Kontak.init();      // info kontak + form validasi

  console.log('✅ Lentera Literasi — semua modul berhasil dimuat.');

});
