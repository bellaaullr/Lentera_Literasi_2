/**
 * js/navigation.js
 * ─────────────────────────────────────────────────────
 * Modul navigasi SPA (Single Page Application).
 * Mengelola perpindahan halaman, navbar scroll effect,
 * dan hamburger menu untuk mobile.
 * ─────────────────────────────────────────────────────
 */

const Navigation = (() => {

  // ── Private state ──
  let activePage = 'home';

  // ── Selector helpers ──
  function getNavbar()    { return document.getElementById('navbar'); }
  function getHamburger() { return document.getElementById('hamburger'); }
  function getNavMenu()   { return document.getElementById('navMenu'); }
  function getAllPages()  { return document.querySelectorAll('.page'); }
  function getAllLinks()  { return document.querySelectorAll('.nav-link'); }

  /**
   * Navigasi ke halaman tertentu.
   * @param {string} pageId - 'home' | 'tbm' | 'kontak'
   */
  function goTo(pageId) {
    if (pageId === activePage) {
      closeMenu();
      return;
    }

    // Sembunyikan semua halaman
    getAllPages().forEach(p => p.classList.remove('active'));

    // Tampilkan halaman target
    const target = document.getElementById(`page-${pageId}`);
    if (target) target.classList.add('active');

    // Update highlight nav link
    getAllLinks().forEach(link => {
      link.classList.toggle('active', link.dataset.page === pageId);
    });

    activePage = pageId;
    closeMenu();
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Kirim event ke modul lain (jika diperlukan)
    document.dispatchEvent(new CustomEvent('pageChanged', { detail: { page: pageId } }));
  }

  /**
   * Tutup mobile menu drawer.
   */
  function closeMenu() {
    getHamburger()?.classList.remove('open');
    getNavMenu()?.classList.remove('open');
  }

  /**
   * Toggle buka/tutup mobile menu.
   */
  function toggleMenu() {
    getHamburger().classList.toggle('open');
    getNavMenu().classList.toggle('open');
  }

  /**
   * Pasang semua event listener navigasi.
   */
  function init() {
    // Nav link klik
    getAllLinks().forEach(link => {
      link.addEventListener('click', e => {
        e.preventDefault();
        goTo(link.dataset.page);
      });
    });

    // Logo → kembali ke Home
    document.getElementById('navLogo')?.addEventListener('click', e => {
      e.preventDefault();
      goTo('home');
    });

    // Hamburger
    getHamburger()?.addEventListener('click', toggleMenu);

    // Tutup menu saat klik di luar navbar
    document.addEventListener('click', e => {
      if (!getNavbar()?.contains(e.target)) closeMenu();
    });

    // Navbar shadow saat scroll
    window.addEventListener('scroll', () => {
      getNavbar()?.classList.toggle('scrolled', window.scrollY > 10);
    });

    // Tombol dengan atribut data-goto (Hero CTA, Banner, dll.)
    document.addEventListener('click', e => {
      const btn = e.target.closest('[data-goto]');
      if (btn) goTo(btn.dataset.goto);
    });
  }

  return { init, goTo };

})();
