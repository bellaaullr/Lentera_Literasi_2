/**
 * js/tbm.js
 * ─────────────────────────────────────────────────────
 * Modul halaman Daftar TBM.
 * - Render filter chips dari area unik
 * - Render kartu TBM dari DATA.tbm (data.js)
 * - Fungsi filter berdasarkan area
 * ─────────────────────────────────────────────────────
 */

const TBM = (() => {

  // ── State filter aktif ──
  let activeFilter = 'all';

  // ── Kumpulkan area unik dari data ──
  function getAreas() {
    const areas = DATA.tbm.map(t => t.area);
    return ['all', ...new Set(areas)];
  }

  /**
   * Buat HTML satu chip filter.
   * @param {string} area
   * @returns {string}
   */
  function createChip(area) {
    const label = area === 'all' ? 'Semua' : area;
    const cls   = area === activeFilter ? 'chip chip--active' : 'chip';
    return `<button class="${cls}" data-area="${area}">${label}</button>`;
  }

  /**
   * Render semua chip ke dalam #filterChips.
   */
  function renderChips() {
    const wrap = document.getElementById('filterChips');
    if (!wrap) return;
    wrap.innerHTML = getAreas().map(createChip).join('');

    // Pasang event listener pada setiap chip
    wrap.querySelectorAll('.chip').forEach(chip => {
      chip.addEventListener('click', () => filterBy(chip.dataset.area));
    });
  }

  /**
   * Buat HTML satu kartu TBM.
   * @param {Object} tbm
   * @returns {string}
   */
  function createCard(tbm) {
    const badgeClass = tbm.buka ? 'badge badge--open' : 'badge badge--closed';
    const badgeIcon  = tbm.buka ? '🟢' : '🔴';

    return `
      <div class="tbm-card" data-area="${tbm.area}" data-id="${tbm.id}">
        <div class="tbm-card__head">
          <span class="tbm-card__icon">${tbm.icon}</span>
          <span class="tbm-card__area">${tbm.area}</span>
        </div>
        <h3 class="tbm-card__name">${tbm.nama}</h3>
        <p class="tbm-card__desc">${tbm.deskripsi}</p>
        <div class="tbm-card__info">
          <div class="info-row"><span>📍</span><span>${tbm.alamat}</span></div>
          <div class="info-row"><span>📞</span><span>${tbm.kontak}</span></div>
        </div>
        <div class="tbm-card__footer">
          <span class="${badgeClass}">${badgeIcon} ${tbm.jadwal}</span>
        </div>
      </div>
    `;
  }

  /**
   * Render semua kartu ke dalam #tbmGrid.
   */
  function renderCards() {
    const grid = document.getElementById('tbmGrid');
    if (!grid) return;
    grid.innerHTML = DATA.tbm.map(createCard).join('');
  }

  /**
   * Filter kartu berdasarkan area yang dipilih.
   * @param {string} area - nama area atau 'all'
   */
  function filterBy(area) {
    activeFilter = area;

    // Update chip aktif
    document.querySelectorAll('.chip').forEach(chip => {
      chip.classList.toggle('chip--active', chip.dataset.area === area);
    });

    // Tampilkan / sembunyikan kartu
    document.querySelectorAll('.tbm-card').forEach(card => {
      const match = area === 'all' || card.dataset.area === area;
      card.classList.toggle('tbm-card--hidden', !match);
    });
  }

  /**
   * Render ulang saat halaman TBM dibuka (agar animasi masuk muncul).
   */
  function onPageShow() {
    renderCards();
    renderChips();

    // Stagger animation
    const cards = document.querySelectorAll('.tbm-card');
    cards.forEach((card, i) => {
      card.style.opacity = '0';
      card.style.transform = 'translateY(18px)';
      setTimeout(() => {
        card.style.transition = 'opacity .35s ease, transform .35s ease';
        card.style.opacity    = '1';
        card.style.transform  = 'translateY(0)';
      }, i * 70);
    });
  }

  /**
   * Inisialisasi modul TBM.
   */
  function init() {
    renderCards();
    renderChips();

    // Dengarkan event perpindahan halaman dari navigation.js
    document.addEventListener('pageChanged', e => {
      if (e.detail.page === 'tbm') onPageShow();
    });
  }

  return { init, filterBy };

})();
